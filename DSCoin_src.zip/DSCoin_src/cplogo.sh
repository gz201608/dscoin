 DST_PNG="DSCoin"
 TOP_PATH="src/qt/res/icons/"
 
 
 cp logo.ico ${TOP_PATH}/bitcoin.ico -f
 cp logo.ico ${TOP_PATH}/bitcoin_testnet.ico -f
 cp logo.ico ${TOP_PATH}/bitbug_favicon.ico -f
 cp logo.ico ${TOP_PATH}/${DST_PNG}.ico -f
 
 cp logo.png ${TOP_PATH}/about.png -f
 cp logo.png ${TOP_PATH}/bitcoin.png -f
 cp logo.png ${TOP_PATH}/bitcoin_testnet.png -f
 
 cp logo.png ${TOP_PATH}/mining.png -f
 cp logo.png ${TOP_PATH}/mining_active.png -f
 cp logo.png ${TOP_PATH}/mining_inactive.png -f
 cp logo.png ${TOP_PATH}/qrcode.png -f
 cp logo.png ${TOP_PATH}/splash.png -f
 cp logo.png ${TOP_PATH}/splash.png -f
 cp logo.png ${TOP_PATH}/splash_testnet.png -f
 cp logo.png ${TOP_PATH}/toolbar.png -f
 cp logo.png ${TOP_PATH}/toolbar_testnet.png -f
 cp logo.png ${TOP_PATH}/wallet.png -f

 
 cp logo.png ${TOP_PATH}/${DST_PNG}.png -f
 cp logo.png ${TOP_PATH}/${DST_PNG}-128.png -f
 cp logo.png ${TOP_PATH}/${DST_PNG}-16.png -f
 
 cp logo.png src/qt/res/images/splash.png -f
 cp logo.png src/qt/res/images/wallet.png -f
 cp logo.png src/qt/res/images/about.png -f
 
 echo "well done"
 